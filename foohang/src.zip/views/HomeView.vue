<script setup>
import SearchBar from "@/components/home/SearchBar.vue";
import Picture from "@/components/home/Picture.vue"
</script>

<template>
  <main>
    <Picture></Picture> 
    <SearchBar></SearchBar>
  </main>
</template>
<style scoped></style>