<script setup>
import CardForm from "@/components/review/CardForm.vue"
</script>

<template>
    <div>
        <h1>리뷰 보기</h1>
        <CardForm></CardForm>
    </div>
</template>

<style scoped>

</style>