<script setup>
import ReviewForm from "@/components/review/ReviewForm.vue"
import ReviewUpload from "@/components/review/ReviewUpload.vue"
</script>

<template>
    <div>
        <ReviewForm></ReviewForm>   
        <ReviewUpload></ReviewUpload>
    </div>
</template>

<style scoped>

</style>