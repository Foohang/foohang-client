<script setup>
import MainHeader from "./components/header/MainHeader.vue";
</script>

<template>
  <MainHeader></MainHeader>
  <RouterView />
</template>

<style scoped></style>
