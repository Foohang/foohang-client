<script setup>

</script>

<template>
    <div>
        <h1>리뷰 작성</h1>
    </div>
</template>

<style scoped>

</style>